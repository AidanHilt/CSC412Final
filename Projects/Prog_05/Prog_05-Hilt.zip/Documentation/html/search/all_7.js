var searchData=
[
  ['sendsortedtoserver',['sendSortedToServer',['../dispatcher_8cpp.html#a73643cbf384fd74a1d377f1e2742b129',1,'dispatcher.cpp']]],
  ['sorter_2ecpp',['sorter.cpp',['../sorter_8cpp.html',1,'']]],
  ['spawnsorterprocess',['spawnSorterProcess',['../dispatcher_8cpp.html#a3c3da5992fa3915e256312eada6b2464',1,'dispatcher.cpp']]]
];
