var searchData=
[
  ['definenumitems',['defineNumItems',['../main_8cpp.html#aea07e89e79b79596cf812cdc435a7490',1,'main.cpp']]],
  ['deletepipes',['deletePipes',['../main_8cpp.html#aad4b09203abf42344c25122d467dce49',1,'main.cpp']]],
  ['dispatchfilesinbatches',['dispatchFilesInBatches',['../main_8cpp.html#a5c684a36b17b8c078566934dd6b3424a',1,'main.cpp']]],
  ['dispatchtextfiles',['dispatchTextFiles',['../dispatcher_8cpp.html#adfc0abc4d8f354bec39b56deb0cc0b95',1,'dispatcher.cpp']]],
  ['distributetoclients',['distributeToClients',['../main_8cpp.html#a2992eacc3b0e0ac2d34f0554d0bc34e9',1,'main.cpp']]]
];
