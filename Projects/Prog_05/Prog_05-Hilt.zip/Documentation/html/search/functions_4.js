var searchData=
[
  ['handleclientdispatches',['handleClientDispatches',['../main_8cpp.html#ace273afcdbb30a9491b04e3681cac31d',1,'main.cpp']]]
];
