 //  Hello  -----  main.c
 //  Created by Jean-Yves Hervé on 2017-10-20.

 #include <stdio.h>

 int main(int argc, const char * argv[])
 {
 	printf("Hello, World!\n");
 	printf("CSC412 - Programming assignment 03\n");
 	return 0;
 }


